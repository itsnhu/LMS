-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: sql101.infinityfree.com
-- Thời gian đã tạo: Th10 30, 2026 lúc 03:16 AM
-- Phiên bản máy phục vụ: 11.4.13-MariaDB
-- Phiên bản PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `if0_43168886_qlgiaynghiphep`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chu_ky`
--

CREATE TABLE `chu_ky` (
  `id` int(11) NOT NULL,
  `nhan_vien_id` int(11) NOT NULL,
  `file_chu_ky` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khoa_phong`
--

CREATE TABLE `khoa_phong` (
  `id` int(11) NOT NULL,
  `ma_khoa` varchar(50) NOT NULL,
  `ten_khoa` varchar(255) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `khoa_phong`
--

INSERT INTO `khoa_phong` (`id`, `ma_khoa`, `ten_khoa`, `mo_ta`, `created_at`) VALUES
(1, 'IT', 'Bộ phận Công nghệ thông tin', 'Quản trị hệ thống CNTT & Phần mềm', '2026-09-21 03:06:14'),
(2, 'BGD', 'Ban Giám đốc', 'Quản lý, điều hành toàn bộ hoạt động bệnh viện', '2026-10-02 03:08:49'),
(3, 'KHTH_QLCL', 'Phòng Kế hoạch tổng hợp & Quản lý chất lượng', 'Kế hoạch điều trị, chỉ đạo tuyến và quản lý chất lượng bệnh viện', '2026-10-02 03:30:14'),
(4, 'DIEU_DUONG', 'Phòng Điều dưỡng', 'Quản lý, chỉ đạo công tác điều dưỡng, chăm sóc bệnh nhân', '2026-10-02 03:32:56'),
(5, 'TCHC_NS', 'Phòng Tổ chức - Hành chính & Nhân sự', 'Quản trị nhân sự, hành chính, pháp chế và truyền thông', '2026-10-03 03:56:21'),
(6, 'TCKT', 'Phòng Tài chính - Kế toán', 'Quản lý tài chính, kế toán, thu ngân và viện phí', '2026-10-03 03:56:54'),
(7, 'CSKH', 'Phòng Chăm sóc khách hàng', 'Đón tiếp, tư vấn, chăm sóc khách hàng', '2026-10-03 03:57:24'),
(8, 'NGOAI', 'Khoa Ngoại Tổng Hợp', 'Phẫu thuật tiêu hóa, gan mật, trĩ, bướu cổ, ngoại chấn thương', '2026-10-03 03:58:45'),
(9, 'NOI', 'Khoa Nội Tổng Hợp', 'Tim mạch, Thần kinh, Hô hấp, Tiêu hóa - Gan mật', '2026-10-03 03:59:10'),
(10, 'LCK', 'Khoa Mắt - Tai Mũi Họng - Răng Hàm Mặt', 'Khám và điều trị các chuyên khoa lẻ, da liễu', '2026-10-03 03:59:50'),
(11, 'KB_CC', 'Khoa Khám bệnh - Cấp cứu', 'Khám bệnh đa khoa, cấp cứu 24/7 và tiếp nhận bệnh nhân', '2026-10-03 04:06:44'),
(12, 'SAN_PHU', 'Khoa Phụ Sản', 'Khám thai, sinh đẻ, phẫu thuật sản phụ khoa và chăm sóc sơ sinh', '2026-10-03 04:07:11'),
(13, 'NHI', 'Khoa Nhi', 'Khám, điều trị bệnh lý nhi khoa và tiêm chủng', '2026-10-03 04:07:35');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep`
--

CREATE TABLE `nghi_phep` (
  `id` int(11) NOT NULL,
  `ma_don` varchar(50) NOT NULL,
  `nhan_vien_id` int(11) NOT NULL,
  `tu_ngay` date NOT NULL,
  `den_ngay` date NOT NULL,
  `buoi_nghi` enum('ca_ngay','sang','chieu') NOT NULL DEFAULT 'ca_ngay',
  `buoi_nghi_ket_thuc` enum('ca_ngay','sang','chieu') NOT NULL DEFAULT 'ca_ngay',
  `so_ngay` decimal(4,1) NOT NULL,
  `ly_do` text NOT NULL,
  `chu_ky_nguoi_nghi` longtext DEFAULT NULL,
  `ho_ten_nguoi_ky` varchar(50) DEFAULT NULL,
  `embed_name_in_sig` tinyint(1) NOT NULL DEFAULT 0,
  `y_kien_truong_khoa` text DEFAULT NULL,
  `chu_ky_truong_khoa` longtext DEFAULT NULL,
  `ho_ten_nguoi_ky_truong_khoa` varchar(50) DEFAULT NULL,
  `nguoi_cho_y_kien` int(11) DEFAULT NULL,
  `ngay_cho_y_kien` datetime DEFAULT NULL,
  `phe_duyet` text DEFAULT NULL,
  `chu_ky_lanh_dao` longtext DEFAULT NULL,
  `ho_ten_nguoi_ky_lanh_dao` varchar(50) DEFAULT NULL,
  `embed_name_in_sig_ld` tinyint(1) NOT NULL DEFAULT 0,
  `nguoi_phe_duyet` int(11) DEFAULT NULL,
  `ngay_phe_duyet` datetime DEFAULT NULL,
  `ngay_nop_nhan_su` date DEFAULT NULL,
  `nguoi_tiep_nhan` int(11) DEFAULT NULL,
  `ngay_tiep_nhan` datetime DEFAULT NULL,
  `da_tru_phep` tinyint(1) NOT NULL DEFAULT 0,
  `so_phep_con_lai_luc_nghi` decimal(4,1) DEFAULT NULL,
  `trang_thai` varchar(50) NOT NULL DEFAULT 'cho_truong_khoa',
  `ly_do_tu_choi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep`
--

INSERT INTO `nghi_phep` (`id`, `ma_don`, `nhan_vien_id`, `tu_ngay`, `den_ngay`, `buoi_nghi`, `buoi_nghi_ket_thuc`, `so_ngay`, `ly_do`, `chu_ky_nguoi_nghi`, `ho_ten_nguoi_ky`, `embed_name_in_sig`, `y_kien_truong_khoa`, `chu_ky_truong_khoa`, `ho_ten_nguoi_ky_truong_khoa`, `nguoi_cho_y_kien`, `ngay_cho_y_kien`, `phe_duyet`, `chu_ky_lanh_dao`, `ho_ten_nguoi_ky_lanh_dao`, `embed_name_in_sig_ld`, `nguoi_phe_duyet`, `ngay_phe_duyet`, `ngay_nop_nhan_su`, `nguoi_tiep_nhan`, `ngay_tiep_nhan`, `da_tru_phep`, `so_phep_con_lai_luc_nghi`, `trang_thai`, `ly_do_tu_choi`, `created_at`, `updated_at`) VALUES
(31, 'NP-20261016-130954-ZH14', 25, '2026-10-17', '2026-10-17', 'sang', 'sang', '0.5', 'việc nhà', 'frontend/uploads/chuky/sign_25_1792130994_c0c49c.png', 'Nguyễn Nhân Viên', 0, 'Duyệt', 'frontend/uploads/chuky/truong_khoa_sign_7_1792131612_6ded05.png', 'Lê Văn N', 7, '2026-10-16 13:20:11', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-16 06:09:53', '2026-10-16 07:48:25'),
(32, 'NP-20261016-150050-5GK4', 25, '2026-10-17', '2026-10-17', 'sang', 'sang', '0.5', 'shdjksdhfk', 'frontend/uploads/chuky/sign_25_1792137650_550c57.png', 'Nguyễn Nhân Viên', 0, 'Duyệt', 'frontend/uploads/chuky/truong_khoa_sign_7_1792137718_c00809.png', 'Lê Văn N', 7, '2026-10-16 15:01:58', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792137740_3ae41d.png', 'Đinh Giám Đốc', 0, 6, '2026-10-16 15:02:20', '2026-10-16', 5, '2026-10-16 15:02:44', 1, '11.5', 'da_tiep_nhan', NULL, '2026-10-16 08:00:49', '2026-10-16 08:02:44'),
(33, 'NP-20261016-150711-E58E', 25, '2026-10-17', '2026-10-17', 'sang', 'sang', '0.5', 'hkjfhskd', 'frontend/uploads/chuky/sign_25_1792138031_d92677.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý kính chuyển Lãnh đạo phê duyệt', 'frontend/uploads/chuky/truong_khoa_sign_7_1792138062_53a106.webp', 'Lê Văn N', 7, '2026-10-16 15:07:42', 'Đồng ý phê duyệt đơn nghỉ phép', 'frontend/uploads/chuky/lanh_dao_sign_6_1792138098_409c3e.webp', 'Đinh Giám Đốc', 0, 6, '2026-10-16 15:08:18', '2026-10-16', 5, '2026-10-23 14:16:21', 1, '10.5', 'da_tiep_nhan', NULL, '2026-10-16 08:07:11', '2026-10-23 07:16:21'),
(34, 'NP-20261017-073150-9VQ2', 25, '2026-10-18', '2026-10-18', 'sang', 'sang', '0.5', 'có việc nhà', 'frontend/uploads/chuky/sign_25_1792197110_e989a0.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý kính chuyển Lãnh đạo phê duyệt', 'frontend/uploads/chuky/truong_khoa_sign_7_1792197172_09f217.jpg', 'Lê Văn N', 7, '2026-10-17 07:32:53', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792330806_2fcbef.webp', 'Đinh Giám Đốc', 0, 6, '2026-10-18 20:40:05', NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-17 00:31:50', '2026-10-18 14:04:37'),
(35, 'NP-20261018-201254-KK26', 25, '2026-10-19', '2026-10-19', 'sang', 'sang', '0.5', 'fjksdklf', 'frontend/uploads/chuky/sign_25_1792329174_7ed61c.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792330170_82b4a6.webp', 'Lê Văn N', 7, '2026-10-18 20:29:29', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792330805_7137af.webp', 'Đinh Giám Đốc', 0, 6, '2026-10-18 20:40:05', NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-18 13:12:54', '2026-10-18 13:57:47'),
(36, 'NP-20261018-201316-9O7R', 26, '2026-10-19', '2026-10-19', 'sang', 'sang', '0.5', 'testtt3432', 'frontend/uploads/chuky/sign_26_1792329196_d01810.png', 'Huỳnh Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792330169_3ca632.webp', 'Lê Văn N', 7, '2026-10-18 20:29:29', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792330805_68da0d.webp', 'Đinh Giám Đốc', 0, 6, '2026-10-18 20:40:05', NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-18 13:13:16', '2026-10-22 07:43:23'),
(37, 'NP-20261019-142741-A18C', 25, '2026-10-20', '2026-10-20', 'sang', 'sang', '0.5', 'ihilfhg', 'frontend/uploads/chuky/sign_25_1792394861_b12e35.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792396429_53deb6.png', 'Lê Văn N', 7, '2026-10-19 14:53:50', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-19 07:27:42', '2026-10-23 07:15:01'),
(38, 'NP-20261019-142842-R9H8', 26, '2026-10-20', '2026-10-20', 'sang', 'sang', '0.5', 'gdfgdfg', 'frontend/uploads/chuky/sign_26_1792394922_7f4d00.png', 'Huỳnh Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792396429_06c7b3.png', 'Lê Văn N', 7, '2026-10-19 14:53:49', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792738346_e0cbfc.webp', 'Đinh Giám Đốc', 0, 6, '2026-10-23 13:52:26', '2026-10-19', 5, '2026-10-23 14:16:21', 1, '10.5', 'da_tiep_nhan', NULL, '2026-10-19 07:28:42', '2026-10-23 07:16:21'),
(39, 'NP-20261022-145615-3X7D', 25, '2026-10-23', '2026-10-23', 'sang', 'sang', '0.5', 'test2210', 'frontend/uploads/chuky/sign_25_1792655775_808f0b.png', 'Nguyễn Nhân Viên', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'da_huy', NULL, '2026-10-22 07:56:16', '2026-10-23 07:15:01'),
(40, 'NP-20261022-145630-II43', 25, '2026-10-23', '2026-10-23', 'chieu', 'chieu', '0.5', 'kjhdsfkjghkdlf', 'frontend/uploads/chuky/sign_25_1792655790_b06974.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792677753_9d5cde.png', 'Lê Văn N', 7, '2026-10-22 21:02:34', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792677781_64929d.png', 'Đinh Giám Đốc', 0, 6, '2026-10-22 21:03:01', '2026-10-22', 5, '2026-10-23 10:08:15', 1, '11.0', 'da_tiep_nhan', NULL, '2026-10-22 07:56:30', '2026-10-23 03:08:15'),
(41, 'NP-20261022-145656-NY08', 26, '2026-10-23', '2026-10-23', 'sang', 'sang', '0.5', 'hfjfhkgjf', 'frontend/uploads/chuky/sign_26_1792655816_b37ba5.png', 'Huỳnh Nhân Viên', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'cho_truong_khoa', NULL, '2026-10-22 07:56:57', '2026-10-22 07:56:57'),
(42, 'NP-20261022-145708-D12L', 26, '2026-10-23', '2026-10-23', 'ca_ngay', 'ca_ngay', '1.0', 'kdsfjlksdjf', 'frontend/uploads/chuky/sign_26_1792655828_b63570.png', 'Huỳnh Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792763180_66cf31.webp', 'Lê Văn N', 7, '2026-10-23 20:46:19', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_25_1792763204_58a15e.png', 'Đinh Tấn Tài', 0, 25, '2026-10-23 20:46:43', '2026-10-22', 5, '2026-10-23 20:47:18', 1, '9.5', 'da_tiep_nhan', NULL, '2026-10-22 07:57:09', '2026-10-23 13:47:18'),
(43, 'NP-20261022-145812-3Q1Y', 26, '2026-10-23', '2026-10-23', 'sang', 'sang', '0.5', 'lfjhgklfd', 'frontend/uploads/chuky/sign_26_1792655892_1c8034.png', 'Huỳnh Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792677571_0a25ee.png', 'Lê Văn N', 7, '2026-10-22 20:59:31', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792677657_fd58c5.png', 'Đinh Giám Đốc', 0, 6, '2026-10-22 21:00:57', '2026-10-22', 5, '2026-10-22 21:28:13', 1, '11.5', 'da_tiep_nhan', NULL, '2026-10-22 07:58:13', '2026-10-22 14:28:13'),
(44, 'NP-20261022-205811-0R6L', 26, '2026-10-23', '2026-10-23', 'sang', 'sang', '0.5', 'fdgdfgfdgdf', 'frontend/uploads/chuky/sign_26_1792677491_3e472f.png', 'Huỳnh Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792677571_45a7b3.png', 'Lê Văn N', 7, '2026-10-22 20:59:31', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792677657_6c347b.png', 'Đinh Giám Đốc', 0, 6, '2026-10-22 21:00:57', '2026-10-22', 5, '2026-10-23 10:08:15', 1, '11.0', 'da_tiep_nhan', NULL, '2026-10-22 13:58:11', '2026-10-23 03:08:15'),
(45, 'NP-20261023-141407-M3B7', 25, '2026-10-24', '2026-10-24', 'sang', 'sang', '0.5', 'gdgfdg', 'frontend/uploads/chuky/sign_25_1792739647_a402d7.png', 'Nguyễn Nhân Viên', 0, 'Đồng ý', 'frontend/uploads/chuky/truong_khoa_sign_7_1792762504_60d723.png', 'Lê Văn N', 7, '2026-10-23 20:35:04', 'Duyệt', 'frontend/uploads/chuky/lanh_dao_sign_6_1792762664_5dc939.png', 'Đinh Giám Đốc', 0, 6, '2026-10-23 20:37:43', '2026-10-23', 5, '2026-10-23 20:38:14', 1, '10.0', 'da_tiep_nhan', NULL, '2026-10-23 07:14:07', '2026-10-23 13:38:14');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep_lich_su`
--

CREATE TABLE `nghi_phep_lich_su` (
  `id` int(11) NOT NULL,
  `nghi_phep_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `thao_tac` varchar(255) NOT NULL,
  `trang_thai_cu` varchar(50) DEFAULT NULL,
  `trang_thai_moi` varchar(50) NOT NULL,
  `ghi_chu` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep_lich_su`
--

INSERT INTO `nghi_phep_lich_su` (`id`, `nghi_phep_id`, `user_id`, `thao_tac`, `trang_thai_cu`, `trang_thai_moi`, `ghi_chu`, `created_at`) VALUES
(89, 31, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-16 06:09:53'),
(90, 31, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Duyệt', '2026-10-16 06:20:11'),
(91, 32, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-16 08:00:49'),
(92, 32, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Duyệt', '2026-10-16 08:01:58'),
(93, 32, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-16 08:02:20'),
(94, 32, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 16/10/2026 — trừ 0.5 ngày phép.', '2026-10-16 08:02:44'),
(95, 33, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-16 08:07:11'),
(96, 33, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý kính chuyển Lãnh đạo phê duyệt', '2026-10-16 08:07:42'),
(97, 33, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Đồng ý phê duyệt đơn nghỉ phép', '2026-10-16 08:08:18'),
(98, 34, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-17 00:31:50'),
(99, 34, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý kính chuyển Lãnh đạo phê duyệt', '2026-10-17 00:32:53'),
(100, 35, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-18 13:12:54'),
(101, 36, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-18 13:13:16'),
(102, 36, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-18 13:29:29'),
(103, 35, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-18 13:29:29'),
(104, 36, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-18 13:40:05'),
(105, 35, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-18 13:40:05'),
(106, 34, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-18 13:40:05'),
(107, 34, 7, 'Trưởng khoa đồng ý hủy đơn', 'cho_huy', 'da_huy', 'Trưởng khoa đồng ý hủy đơn', '2026-10-18 14:04:37'),
(108, 37, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-19 07:27:42'),
(109, 38, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-19 07:28:42'),
(110, 38, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-19 07:53:49'),
(111, 37, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-19 07:53:50'),
(112, 36, 7, 'Trưởng khoa đồng ý hủy đơn', 'cho_huy', 'da_huy', 'Duyệt hàng loạt', '2026-10-22 07:43:23'),
(113, 39, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-22 07:56:16'),
(114, 40, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi chiều)', '2026-10-22 07:56:30'),
(115, 41, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-22 07:56:57'),
(116, 42, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 1 ngày (ca: Cả ngày)', '2026-10-22 07:57:09'),
(117, 43, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-22 07:58:13'),
(118, 44, 24, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-22 13:58:11'),
(119, 44, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-22 13:59:31'),
(120, 43, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-22 13:59:31'),
(121, 44, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-22 14:00:57'),
(122, 43, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-22 14:00:57'),
(123, 40, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-22 14:02:34'),
(124, 40, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-22 14:03:01'),
(125, 43, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 22/10/2026 — trừ 0.5 ngày phép.', '2026-10-22 14:28:13'),
(126, 40, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép (Hàng loạt)', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 22/10/2026 — trừ 0.5 ngày phép.', '2026-10-23 03:08:15'),
(127, 44, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép (Hàng loạt)', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 22/10/2026 — trừ 0.5 ngày phép.', '2026-10-23 03:08:15'),
(128, 38, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-23 06:52:26'),
(129, 45, 23, 'Tạo và gửi', NULL, 'cho_truong_khoa', 'Nhân viên tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng)', '2026-10-23 07:14:07'),
(130, 39, 7, 'Trưởng khoa đồng ý hủy đơn', 'cho_huy', 'da_huy', 'Duyệt hàng loạt', '2026-10-23 07:15:01'),
(131, 37, 7, 'Trưởng khoa đồng ý hủy đơn', 'cho_huy', 'da_huy', 'Duyệt hàng loạt', '2026-10-23 07:15:01'),
(132, 38, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép (Hàng loạt)', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 19/10/2026 — trừ 0.5 ngày phép.', '2026-10-23 07:16:21'),
(133, 33, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép (Hàng loạt)', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 16/10/2026 — trừ 0.5 ngày phép.', '2026-10-23 07:16:21'),
(134, 45, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-23 13:35:04'),
(135, 45, 6, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-23 13:37:43'),
(136, 45, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 23/10/2026 — trừ 0.5 ngày phép.', '2026-10-23 13:38:14'),
(137, 42, 7, 'Trưởng khoa đồng ý & chuyển Lãnh đạo (Kèm chữ ký)', 'cho_truong_khoa', 'cho_phe_duyet', 'Đồng ý', '2026-10-23 13:46:19'),
(138, 42, 25, 'Lãnh đạo phê duyệt (Kèm chữ ký)', 'cho_phe_duyet', 'da_duyet', 'Duyệt', '2026-10-23 13:46:43'),
(139, 42, 5, 'Phòng Nhân sự tiếp nhận giấy & trừ phép', 'da_duyet', 'da_tiep_nhan', 'Xác nhận Ngày nộp: 22/10/2026 — trừ 1 ngày phép.', '2026-10-23 13:47:18');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id` int(11) NOT NULL,
  `ma_nv` varchar(50) NOT NULL,
  `ho_ten` varchar(255) NOT NULL,
  `chuc_vu` varchar(255) NOT NULL,
  `khoa_phong_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `gioi_tinh` varchar(10) DEFAULT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `ngay_vao_lam` date DEFAULT NULL,
  `chu_ky_mac_dinh` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`id`, `ma_nv`, `ho_ten`, `chuc_vu`, `khoa_phong_id`, `email`, `so_dien_thoai`, `ngay_sinh`, `gioi_tinh`, `dia_chi`, `ngay_vao_lam`, `chu_ky_mac_dinh`, `created_at`, `updated_at`) VALUES
(1, 'NV001', 'NGUYỄN NGỌC', 'Quản trị hệ thống', 1, 'admin@bvtamtri.vn', '0901234567', '1998-03-03', NULL, NULL, '2020-01-01', NULL, '2026-09-21 03:06:14', '2026-10-12 06:34:42'),
(6, 'GDDH', 'Đinh Giám Đốc', 'Thạc sĩ - Bác sĩ', 2, 'gd123@gmail.com', '0922113344', NULL, NULL, NULL, NULL, NULL, '2026-10-02 04:27:13', '2026-10-05 03:19:42'),
(7, 'NHANSU01', 'PHẠM THỊ NHÂN SỰ', 'NHAN_VIEN_HANH_CHINH', 5, 'nhansu01@gmail.com', '0911223344', '1995-05-09', 'Nữ', NULL, NULL, NULL, '2026-10-02 06:04:47', '2026-10-18 13:10:02'),
(8, 'TRP01', 'LÊ VĂN N', 'TRUONG_PHONG', 1, 'it01@gmail.com', '0911223344', '1990-01-01', 'Nam', 'Cao Lãnh, Đồng Tháp', NULL, NULL, '2026-10-02 07:30:34', '2026-10-21 01:30:37'),
(25, 'NV01', 'NGUYỄN NHÂN VIÊN', 'NHAN_VIEN_IT', 1, 'test01@gmail.com', '0911223344', '1999-01-01', 'Nam', 'Phường 1, Cao Lãnh, Đồng Tháp', NULL, NULL, '2026-10-16 06:08:55', '2026-10-16 06:08:55'),
(26, 'NV02', 'HUỲNH NHÂN VIÊN', 'NHAN_VIEN_IT', 1, 'test02@gmail.com', '0922331144', '1997-04-05', 'Nữ', NULL, NULL, NULL, '2026-10-18 13:11:12', '2026-10-21 03:10:30'),
(27, 'TEST123', 'ĐINH TẤN TÀI', 'PGD', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-10-23 13:45:11', '2026-10-23 13:45:35');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tieu_de` varchar(255) NOT NULL,
  `noi_dung` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `da_doc` tinyint(1) NOT NULL DEFAULT 0,
  `loai` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `tieu_de`, `noi_dung`, `link`, `da_doc`, `loai`, `created_at`) VALUES
(1, 5, '🔐 Mật khẩu đã được thay đổi', 'Mật khẩu tài khoản \"nhasu01\" của bạn vừa được thay đổi lúc 13:53 02/10/2026. Nếu không phải bạn thực hiện, vui lòng liên hệ Phòng IT ngay!', NULL, 0, NULL, '2026-10-02 06:53:49'),
(2, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261002-110629-S7V2)', 'banlanhdao/duyetlanhdao.html', 1, NULL, '2026-10-02 07:33:08'),
(4, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261002-110629-S7V2 của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-02 07:35:51'),
(5, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN VĂN A vừa tạo đơn nghỉ 1 ngày (ca: Cả ngày) - Mã đơn: NP-20261006-073312-R2X6', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-06 00:33:12'),
(6, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN VĂN A (NP-20261006-073312-R2X6)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-06 00:36:47'),
(8, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261006-073312-R2X6 của NGUYỄN VĂN A đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-06 00:58:56'),
(10, 7, 'Có giấy nghỉ phép mới', 'Nhân viên LÊ VĂN N vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261006-112629-QK29', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-06 04:26:30'),
(11, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261006-112732-S9I0', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-06 04:27:33'),
(12, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261006-112732-S9I0)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-06 04:29:03'),
(14, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261006-112732-S9I0 của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-06 04:30:16'),
(16, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN VĂN A vừa tạo đơn nghỉ 1 ngày (ca: Cả ngày) - Mã đơn: NP-20261008-090836-8KR7', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 02:08:36'),
(17, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN VĂN A (NP-20261008-090836-8KR7)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 02:13:59'),
(19, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-090836-8KR7 của NGUYỄN VĂN A đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 02:15:13'),
(21, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN VĂN A vừa tạo đơn nghỉ 1.5 ngày (ca: Buổi chiều (đầu) → Cả ngày (cuối)) - Mã đơn: NP-20261008-100804-4WB1', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 03:08:04'),
(22, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN VĂN A (NP-20261008-100804-4WB1)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 03:35:57'),
(24, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-100804-4WB1 của NGUYỄN VĂN A đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 03:41:32'),
(26, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261008-110320-B84J', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 04:03:20'),
(27, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261008-110320-B84J)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 04:04:00'),
(29, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-110320-B84J của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 04:05:24'),
(31, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261008-111018-Y64M', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 04:10:18'),
(32, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261008-111018-Y64M)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 04:11:08'),
(34, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-111018-Y64M của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 04:11:49'),
(36, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi chiều) - Mã đơn: NP-20261008-111911-25VX', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 04:19:11'),
(37, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261008-111911-25VX)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 04:20:00'),
(39, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-111911-25VX của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 04:20:37'),
(40, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 1.5 ngày (ca: Buổi sáng (đầu) → Cả ngày (cuối)) - Mã đơn: NP-20261008-112502-G5S3', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 04:25:02'),
(41, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261008-112502-G5S3)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 04:26:17'),
(43, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-112502-G5S3 của OGGY FULL STACK đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 04:26:58'),
(44, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261008-120618-2VB3', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 05:06:18'),
(45, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261008-120618-2VB3)', 'banlanhdao/duyetlanhdao.html', 0, NULL, '2026-10-08 05:07:36'),
(47, 5, 'Có giấy nghỉ phép mới cần tiếp nhận', 'Đơn NP-20261008-120618-2VB3 của NGUYỄN NHÂN VIÊN đã được Ban Giám Đốc duyệt.', '/frontend/nhansutiepnhan/tiepnhan.html', 0, NULL, '2026-10-08 05:08:13'),
(48, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 1.5 ngày (ca: Buổi sáng (đầu) → Cả ngày (cuối)) - Mã đơn: NP-20261008-131537-D1A4', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 06:15:38'),
(49, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 1.5 ngày (ca: Buổi sáng (đầu) → Cả ngày (cuối)) - Mã đơn: NP-20261008-142045-J2E3', 'banlanhdao/duyettruongkhoa.html', 1, NULL, '2026-10-08 07:20:46'),
(50, 1, '🔐 Mật khẩu đã được thay đổi', 'Mật khẩu tài khoản \"admin\" của bạn vừa được thay đổi lúc 20:48 08/10/2026. Nếu không phải bạn thực hiện, vui lòng liên hệ Phòng IT ngay!', NULL, 0, NULL, '2026-10-08 13:48:59'),
(51, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NGỌC NHƯ vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261009-082537-H66V', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 01:25:37'),
(53, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NGỌC NHƯ (NP-20261009-082537-H66V)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 02:28:29'),
(54, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NGỌC NHƯ vừa tạo đơn nghỉ 2 ngày (ca: Buổi sáng) - Mã đơn: NP-20261009-093142-5AK7', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 02:31:42'),
(56, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NGỌC NHƯ (NP-20261009-093142-5AK7)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 02:32:32'),
(57, 1, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261009-093142-5AK7 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-09 03:24:27'),
(58, 1, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261009-082537-H66V của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-09 03:35:49'),
(59, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 1.5 ngày (ca: Buổi sáng (đầu) → Cả ngày (cuối)) - Mã đơn: NP-20261009-143904-W88W', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 07:39:05'),
(61, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 1 ngày (ca: Cả ngày) - Mã đơn: NP-20261009-143951-L7Y2', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 07:39:52'),
(63, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261009-143951-L7Y2)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 07:41:30'),
(65, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261009-150918-U73V', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 08:09:19'),
(67, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261009-143904-W88W)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 08:10:29'),
(69, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261009-150918-U73V)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 08:13:08'),
(71, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261008-142045-J2E3)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 08:32:22'),
(74, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của SAN NV (NP-20261009-204420-IK62)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 13:45:44'),
(78, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của SAN NV (NP-20261009-210345-01DV)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 14:04:56'),
(80, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261009-211102-G4H1', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-09 14:11:01'),
(82, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261009-211102-G4H1)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-09 14:11:48'),
(85, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của SAN NV (NP-20261010-091759-05WO)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-10 02:30:24'),
(87, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của SAN NV (NP-20261010-093134-N00D)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-10 02:35:37'),
(88, 7, 'Yêu cầu hủy đơn nghỉ phép', 'Nhân viên OGGY FULL STACK gửi yêu cầu hủy đơn NP-20261002-110629-S7V2', 'truongkhoaduyetdonnghiphep.html?tab=pending', 1, NULL, '2026-10-10 04:24:18'),
(91, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261010-123102-77RE', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-10 05:31:02'),
(93, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261010-123102-77RE)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-10 05:31:37'),
(95, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 1 ngày (ca: Cả ngày) - Mã đơn: NP-20261012-133744-4E2Q', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-12 06:37:44'),
(97, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261012-133744-4E2Q)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-12 06:38:11'),
(100, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261012-134911-U5V6', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-12 06:49:11'),
(102, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261012-134911-U5V6)', 'lanhdaoduyetdonnghiphep.html', 1, NULL, '2026-10-12 06:49:37'),
(104, 7, 'Có giấy nghỉ phép mới', 'Nhân viên OGGY FULL STACK vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261012-135938-W8P4', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-12 06:59:38'),
(106, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của OGGY FULL STACK (NP-20261012-135938-W8P4)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-12 07:00:09'),
(108, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261012-141217-N3Y7', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-12 07:12:17'),
(110, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261012-141217-N3Y7)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-12 07:12:41'),
(111, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261016-130954-ZH14', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-16 06:09:53'),
(112, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261016-130954-ZH14)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-16 06:20:11'),
(113, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261016-150050-5GK4', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-16 08:00:49'),
(114, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261016-150050-5GK4)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-16 08:01:58'),
(115, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261016-150050-5GK4 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-16 08:02:20'),
(116, 23, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261016-150050-5GK4 đã được tiếp nhận (Ngày nộp: 16/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-16 08:02:44'),
(117, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261016-150711-E58E', 'truongkhoaduyetdonnghiphep.html', 1, NULL, '2026-10-16 08:07:11'),
(118, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261016-150711-E58E)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-16 08:07:42'),
(119, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261016-150711-E58E của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-16 08:08:18'),
(120, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261017-073150-9VQ2', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-17 00:31:50'),
(121, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261017-073150-9VQ2)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-17 00:32:53'),
(122, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261018-201254-KK26', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-18 13:12:54'),
(123, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261018-201316-9O7R', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-18 13:13:16'),
(124, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261018-201316-9O7R)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-18 13:29:29'),
(125, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261018-201254-KK26)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-18 13:29:29'),
(126, 24, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261018-201316-9O7R của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-18 13:40:05'),
(127, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261018-201254-KK26 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-18 13:40:05'),
(128, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261017-073150-9VQ2 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-18 13:40:05'),
(129, 23, 'Đơn nghỉ phép đã được hủy', 'Trưởng khoa đã ĐỒNG Ý HỦY đơn NP-20261017-073150-9VQ2 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-18 14:04:37'),
(130, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261019-142741-A18C', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-19 07:27:42'),
(131, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261019-142842-R9H8', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-19 07:28:42'),
(132, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261019-142842-R9H8)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-19 07:53:49'),
(133, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261019-142741-A18C)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-19 07:53:50'),
(134, 24, 'Đơn nghỉ phép đã được hủy', 'Trưởng khoa đã ĐỒNG Ý HỦY đơn NP-20261018-201316-9O7R của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-22 07:43:23'),
(135, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261022-145615-3X7D', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 07:56:16'),
(136, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi chiều) - Mã đơn: NP-20261022-145630-II43', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 07:56:30'),
(137, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261022-145656-NY08', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 07:56:57'),
(138, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 1 ngày (ca: Cả ngày) - Mã đơn: NP-20261022-145708-D12L', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 07:57:09'),
(139, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261022-145812-3Q1Y', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 07:58:13'),
(140, 7, 'Có giấy nghỉ phép mới', 'Nhân viên HUỲNH NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261022-205811-0R6L', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-22 13:58:11'),
(141, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261022-205811-0R6L)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-22 13:59:31'),
(142, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261022-145812-3Q1Y)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-22 13:59:31'),
(143, 24, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261022-205811-0R6L của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-22 14:00:57'),
(144, 24, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261022-145812-3Q1Y của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-22 14:00:57'),
(145, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261022-145630-II43)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-22 14:02:34'),
(146, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261022-145630-II43 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-22 14:03:01'),
(147, 24, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261022-145812-3Q1Y đã được tiếp nhận (Ngày nộp: 22/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-22 14:28:13'),
(148, 23, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261022-145630-II43 đã được tiếp nhận (Ngày nộp: 22/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 03:08:15');
INSERT INTO `notifications` (`id`, `user_id`, `tieu_de`, `noi_dung`, `link`, `da_doc`, `loai`, `created_at`) VALUES
(149, 24, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261022-205811-0R6L đã được tiếp nhận (Ngày nộp: 22/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 03:08:15'),
(150, 5, '🔐 Mật khẩu đã được thay đổi', 'Mật khẩu tài khoản \"nhansu01\" của bạn vừa được thay đổi lúc 13:11 23/10/2026. Nếu không phải bạn thực hiện, vui lòng liên hệ Phòng IT ngay!', NULL, 0, NULL, '2026-10-23 06:11:20'),
(151, 5, '🔐 Mật khẩu đã được thay đổi', 'Mật khẩu tài khoản \"nhansu01\" của bạn vừa được thay đổi lúc 13:11 23/10/2026. Nếu không phải bạn thực hiện, vui lòng liên hệ Phòng IT ngay!', NULL, 0, NULL, '2026-10-23 06:11:53'),
(152, 24, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261019-142842-R9H8 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 06:52:26'),
(153, 7, 'Có giấy nghỉ phép mới', 'Nhân viên NGUYỄN NHÂN VIÊN vừa tạo đơn nghỉ 0.5 ngày (ca: Buổi sáng) - Mã đơn: NP-20261023-141407-M3B7', 'truongkhoaduyetdonnghiphep.html', 0, NULL, '2026-10-23 07:14:07'),
(154, 23, 'Đơn nghỉ phép đã được hủy', 'Trưởng khoa đã ĐỒNG Ý HỦY đơn NP-20261022-145615-3X7D của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 07:15:01'),
(155, 23, 'Đơn nghỉ phép đã được hủy', 'Trưởng khoa đã ĐỒNG Ý HỦY đơn NP-20261019-142741-A18C của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 07:15:01'),
(156, 24, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261019-142842-R9H8 đã được tiếp nhận (Ngày nộp: 19/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 07:16:21'),
(157, 23, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261016-150711-E58E đã được tiếp nhận (Ngày nộp: 16/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 07:16:21'),
(158, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của NGUYỄN NHÂN VIÊN (NP-20261023-141407-M3B7)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-23 13:35:04'),
(159, 23, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261023-141407-M3B7 của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 13:37:43'),
(160, 23, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261023-141407-M3B7 đã được tiếp nhận (Ngày nộp: 23/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 13:38:14'),
(161, 6, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261022-145708-D12L)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-23 13:46:19'),
(162, 25, 'Có giấy nghỉ phép mới cần phê duyệt', 'Trưởng khoa đã cho ý kiến đơn của HUỲNH NHÂN VIÊN (NP-20261022-145708-D12L)', 'lanhdaoduyetdonnghiphep.html', 0, NULL, '2026-10-23 13:46:19'),
(163, 24, 'Giấy nghỉ phép đã được phê duyệt', 'Lãnh đạo đã phê duyệt đơn NP-20261022-145708-D12L của bạn.', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 13:46:43'),
(164, 24, 'Phòng Nhân sự đã tiếp nhận giấy nghỉ phép', 'Giấy nghỉ phép NP-20261022-145708-D12L đã được tiếp nhận (Ngày nộp: 22/10/2026)', 'lichsudonnghiphep.html', 0, NULL, '2026-10-23 13:47:18');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phep_nam`
--

CREATE TABLE `phep_nam` (
  `id` int(11) NOT NULL,
  `nhan_vien_id` int(11) NOT NULL,
  `nam` int(11) NOT NULL,
  `phep_nam` decimal(4,1) NOT NULL DEFAULT 12.0,
  `phep_tham_nien` decimal(4,1) NOT NULL DEFAULT 0.0,
  `phep_chuyen_sang` decimal(4,1) NOT NULL DEFAULT 0.0,
  `so_ngay_da_nghi` decimal(4,1) NOT NULL DEFAULT 0.0,
  `ghi_chu` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `phep_nam`
--

INSERT INTO `phep_nam` (`id`, `nhan_vien_id`, `nam`, `phep_nam`, `phep_tham_nien`, `phep_chuyen_sang`, `so_ngay_da_nghi`, `ghi_chu`, `created_at`, `updated_at`) VALUES
(5, 6, 2026, '12.0', '0.0', '0.0', '0.0', NULL, '2026-10-02 04:27:13', '2026-10-02 04:27:13'),
(6, 7, 2026, '12.0', '0.0', '0.0', '0.0', NULL, '2026-10-02 06:04:48', '2026-10-02 06:04:48'),
(7, 8, 2026, '12.0', '0.0', '0.0', '0.0', NULL, '2026-10-02 07:30:34', '2026-10-02 07:30:34'),
(17, 1, 2026, '12.0', '0.0', '0.0', '0.0', NULL, '2026-10-09 01:35:46', '2026-10-09 01:35:46'),
(25, 25, 2026, '12.0', '0.0', '0.0', '2.0', NULL, '2026-10-16 06:08:55', '2026-10-23 13:38:14'),
(26, 26, 2026, '12.0', '0.0', '0.0', '2.5', NULL, '2026-10-18 13:11:13', '2026-10-23 13:47:18'),
(27, 27, 2026, '12.0', '0.0', '0.0', '0.0', NULL, '2026-10-23 13:45:11', '2026-10-23 13:45:11');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `vai_tro` enum('admin','nhan_vien','truong_khoa','lanh_dao','nhan_su') NOT NULL DEFAULT 'nhan_vien',
  `nhan_vien_id` int(11) DEFAULT NULL,
  `trang_thai` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `vai_tro`, `nhan_vien_id`, `trang_thai`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$12$wxajnm/tA.GVwJkbyAuGLehdmMio8J53iAnrdp8rVP53NCS4ZCSna', 'admin', 1, 1, '2026-10-26 23:21:43', '2026-09-21 03:06:14', '2026-10-26 16:21:43'),
(5, 'nhansu01', '$2y$12$/Bdlb3BeowywX3a7cDDP2ePpUCm2helR/BaGHvR9QFEEOewBhYqg6', 'nhan_su', 7, 1, '2026-10-29 22:29:28', '2026-10-02 06:04:48', '2026-10-29 15:29:28'),
(6, 'gddh', '$2y$12$G7mt/4P/aYWrr6s7KIJpBOyWIcJ3ISVtrftrC4vRKzmdq6CVbcx2q', 'lanh_dao', 6, 1, '2026-10-23 20:37:10', '2026-10-02 06:25:51', '2026-10-23 13:37:10'),
(7, 'trp01', '$2y$12$laOZsG96mHifX3rTu6Y6/.HieJtFMUGN/URQUnugLwPJMLS8QVJXu', 'truong_khoa', 8, 1, '2026-10-29 22:21:25', '2026-10-02 07:31:08', '2026-10-29 15:21:25'),
(23, 'nv01', '$2y$12$SqqAFCfWuFu4WL44i4NKZuNP7Z8qnyXukKhGPtW3k6CzXSDMnzw1e', 'nhan_vien', 25, 1, '2026-10-29 22:09:14', '2026-10-16 06:09:12', '2026-10-29 15:09:14'),
(24, 'nv02', '$2y$12$p.Vp4iYbeQw1Z0/SodGaC.5RsaiNco67cEALCJNbFqzDlxicx5Bg2', 'nhan_vien', 26, 1, '2026-10-23 20:46:53', '2026-10-18 13:11:13', '2026-10-23 13:46:53'),
(25, 'giamdoc', '$2y$12$m/VYSAQX4dY1AslTSlzYMeQkxGOcqFXqjKpFQbyMUbqBmfiXJ35ha', 'lanh_dao', 27, 1, '2026-10-23 20:46:29', '2026-10-23 13:45:11', '2026-10-23 13:46:29');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chu_ky`
--
ALTER TABLE `chu_ky`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nhan_vien_id` (`nhan_vien_id`);

--
-- Chỉ mục cho bảng `khoa_phong`
--
ALTER TABLE `khoa_phong`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ma_khoa` (`ma_khoa`);

--
-- Chỉ mục cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ma_don` (`ma_don`),
  ADD KEY `nhan_vien_id` (`nhan_vien_id`);

--
-- Chỉ mục cho bảng `nghi_phep_lich_su`
--
ALTER TABLE `nghi_phep_lich_su`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nghi_phep_id` (`nghi_phep_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ma_nv` (`ma_nv`),
  ADD KEY `khoa_phong_id` (`khoa_phong_id`);

--
-- Chỉ mục cho bảng `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `phep_nam`
--
ALTER TABLE `phep_nam`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_nv_nam` (`nhan_vien_id`,`nam`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `nhan_vien_id` (`nhan_vien_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chu_ky`
--
ALTER TABLE `chu_ky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `khoa_phong`
--
ALTER TABLE `khoa_phong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `nghi_phep_lich_su`
--
ALTER TABLE `nghi_phep_lich_su`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT cho bảng `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT cho bảng `phep_nam`
--
ALTER TABLE `phep_nam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chu_ky`
--
ALTER TABLE `chu_ky`
  ADD CONSTRAINT `chu_ky_ibfk_1` FOREIGN KEY (`nhan_vien_id`) REFERENCES `nhan_vien` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD CONSTRAINT `nghi_phep_ibfk_1` FOREIGN KEY (`nhan_vien_id`) REFERENCES `nhan_vien` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep_lich_su`
--
ALTER TABLE `nghi_phep_lich_su`
  ADD CONSTRAINT `nghi_phep_lich_su_ibfk_1` FOREIGN KEY (`nghi_phep_id`) REFERENCES `nghi_phep` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `nghi_phep_lich_su_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`khoa_phong_id`) REFERENCES `khoa_phong` (`id`);

--
-- Các ràng buộc cho bảng `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `phep_nam`
--
ALTER TABLE `phep_nam`
  ADD CONSTRAINT `phep_nam_ibfk_1` FOREIGN KEY (`nhan_vien_id`) REFERENCES `nhan_vien` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`nhan_vien_id`) REFERENCES `nhan_vien` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
